# cpp-graduate
Code samples for C++ graduate course (iLab at MIPT)

Slides can be found here: https://sourceforge.net/projects/cpp-lects-rus/files/cpp-graduate/
