#include <stdio.h>

extern int foo();

int main() { printf("%d\n", foo()); }
