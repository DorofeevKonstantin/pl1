int g;

void foo(int *x) { g = *x; }

void bar(int &x) { g = x; }
