int foo() { return 24; }
