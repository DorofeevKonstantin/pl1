extern int foo(int x) { return x; }

static int bar(int x) { return x; }
