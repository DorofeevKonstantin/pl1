//-----------------------------------------------------------------------------
//
// Source code for MIPT ILab
// Slides: https://sourceforge.net/projects/cpp-lects-rus/files/cpp-graduate/
// Licensed after GNU GPL v3
//
//-----------------------------------------------------------------------------
//
// Init order demo: static initialization order
// compile with: 
// g++ module-2.cc module-1.cc
// g++ module-1.cc module-2.cc
//
//-----------------------------------------------------------------------------

#pragma once

extern int a, b;
